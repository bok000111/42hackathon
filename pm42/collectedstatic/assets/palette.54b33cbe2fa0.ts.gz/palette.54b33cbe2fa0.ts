export const palette = {
  MainColor: "#00BABC",
  LightGray: "#EEEEEE",
  SubColor: "#BFF2F2",
  Gray: "#A3A3A3",
  White: "#FFFFFF",
};
